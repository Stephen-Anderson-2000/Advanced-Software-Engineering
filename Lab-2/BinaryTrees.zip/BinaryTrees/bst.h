#ifndef BST_H
#define BST_H

#include <string>

class BST
{
public:
    using KeyType = int;
    using ItemType = std::string;
    BST() = default;

    ItemType* lookup(KeyType);
    void insert(KeyType, ItemType);
    void remove(KeyType);
    void displayEntries();

private:
    struct Node;
    Node* root = leaf();
    static Node* leaf();
    static bool isLeaf(Node*);
    ItemType* lookupRec(KeyType, Node*);
    void insertRec(KeyType, ItemType, Node* &);
};

#endif // BST_H
