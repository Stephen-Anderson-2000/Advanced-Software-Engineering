#include "bst.h"

struct BST::Node
{
    Node(BST::KeyType, BST::ItemType);
    BST::KeyType key;
    BST::ItemType item;
    Node* leftChild;
    Node* rightChild;
};

BST::Node* BST::leaf()
{
    return nullptr;
}

bool BST::isLeaf(Node* n)
{
    return (n == nullptr);
}

BST::Node::Node(KeyType key, ItemType item)
{
    this->key = key;
    this->item = item;
    this->leftChild = nullptr;
    this->rightChild = nullptr;
}

/*
BST::ItemType* BST::lookup(KeyType soughtKey)
{
    Node* currentNode = this->root;
    while (true)
    {
        if (isLeaf(currentNode))
        {
            return nullptr;
        }
        else if (currentNode->key == soughtKey)
        {
            return &currentNode->item;
        }
        else if (currentNode->key > soughtKey)
        {
            currentNode = currentNode->leftChild;
        }
        else if (currentNode->key < soughtKey)
        {
            currentNode = currentNode->rightChild;
        }
    } // Uses same logic as older version of the recursive algorithm. DO NOT USE!
}
*/

BST::ItemType* BST::lookup(KeyType soughtKey)
{
    return (lookupRec(soughtKey, this->root));
} // Essentially an API to interact with the recursive function

BST::ItemType* BST::lookupRec(KeyType soughtKey, Node* currentNode)
{
    if (currentNode != nullptr)
    {
        if (soughtKey == currentNode->key)
        {
            return &currentNode->item;
        }
        if(!isLeaf(currentNode))
        {
            if (soughtKey < currentNode->key)
            {
                return lookupRec(soughtKey, currentNode->leftChild);
            }
            else if (soughtKey > currentNode->key)
            {
                return lookupRec(soughtKey, currentNode->rightChild);
            }
        }
    }
    return nullptr;
}

/*
void BST::insert(KeyType newKey, ItemType newItem)
{
    Node newNode(newKey, newItem);
    Node* currentNode = this->root;
    bool iterating = true;
    while (iterating)
    {
        if (isLeaf(currentNode))
        {
            if (currentNode == nullptr)
            {
                currentNode = newNode;
            }
            else if (newKey < currentNode->key)
            {
                currentNode->leftChild = &newNode;
            }
            else
            {
                currentNode->rightChild = &newNode;
            }
            iterating = false;
        }
        else if (newKey < currentNode->key)
        {
            currentNode = currentNode->leftChild;
        }
        else if (newKey > currentNode->key)
        {
            currentNode = currentNode->rightChild;
        }
        else if (newKey == currentNode->key)
        {
            currentNode->item = newItem;
        }
    }
}
*/

void BST::insert(KeyType newKey, ItemType newItem)
{
    insertRec(newKey, newItem, this->root);
}

void BST::insertRec(KeyType newKey, ItemType newItem, Node* &currentNode)
{
    if (isLeaf(currentNode))
    {
        Node* newNode = new Node(newKey, newItem);
        if (currentNode == nullptr)
        {
            currentNode = newNode;
        }
    }
    else if (newKey == currentNode->key)
    {
        currentNode->item = newItem;
    }

    if (newKey < currentNode->key)
    {
        insertRec(newKey, newItem, currentNode->leftChild);
    }
    else if (newKey > currentNode->key)
    {
        insertRec(newKey, newItem, currentNode->rightChild);
    }
}

/*
void BST::displayEntries()
{

}

void BST::displayInOrder()
{

}
*/
